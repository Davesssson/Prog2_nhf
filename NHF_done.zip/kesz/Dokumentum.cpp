#include "Dokumentum.h"


string Dokumentum::get_leiras() {
    return leiras;
}
void Dokumentum::set_leiras(string ujleiras) {
    leiras = ujleiras;
}
void Dokumentum::kiir() {
    Film::kiir();
    cout << "Leiras: " << "\t" << "[" << leiras << "]" << endl;
    cout << endl;
}
void Dokumentum::fajlbakiir(ofstream& os) {
    Film::fajlbakiir(os);
    os << leiras;
}
void Dokumentum::valtoztat(Film* param) {
    cout << "[Adja meg az uj leirast!]\n";
    Dokumentum* uj = dynamic_cast<Dokumentum*>(param);
   
    string ujleiras;
    cin.ignore(1, '\n');
    getline(cin, ujleiras);
    uj->set_leiras(ujleiras);
   
}
Dokumentum* Dokumentum:: clone() {
    return new Dokumentum(*this);
}

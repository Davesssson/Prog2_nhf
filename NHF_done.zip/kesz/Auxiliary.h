#pragma once
#include <string>
using namespace std;


void megjelenit();
int char_to_int(string param);
bool isint(char const* param);

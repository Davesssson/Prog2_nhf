#include "Csaladi.h"

int Csaladi::get_korhatar() {
    return korhatar;
}
void Csaladi::set_korhatar(int ujkorhatar) {
    korhatar = ujkorhatar;
}
void Csaladi::kiir() {
    Film::kiir();
    cout << "Korhatar: " << "\t" << "[" << korhatar << "]" << endl;
    cout << endl;
}
void Csaladi::fajlbakiir(ofstream& os) {
    Film::fajlbakiir(os);
    os << korhatar;
}

void Csaladi::valtoztat(Film* param) {
    cout << "[Adja meg az uj korhatart!]\n";
    Csaladi* uj = dynamic_cast<Csaladi*>(param);
    int ujkorhatar;
    cin >> ujkorhatar;
    uj->set_korhatar(ujkorhatar);
}

Csaladi* Csaladi:: clone() {
    return new Csaladi(*this);
}

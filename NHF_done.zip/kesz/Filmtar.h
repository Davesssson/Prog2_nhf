#pragma once

#include "Film.h"

class Filmtar {
    size_t db;
    
    Film** Tarolo;

public:
    Filmtar( ) {
        db = 0;
        Tarolo = new Film * [db];
    }

   
 
    Filmtar& operator=(Filmtar const& rhs) {        // 7. labor alapj�n
        if (this != &rhs) {
         
            felszabadit();
            Tarolo = new Film * [rhs.db];
            for (size_t i = 0; i < rhs.db; i++) {
                Tarolo[i] = rhs.Tarolo[i];
               //Tarolo[i] = rhs.Tarolo[i]->clone();
            }
            db = rhs.db;
        }
        return *this;

    }


    Film* operator[](size_t i)const {
        if (i < 0 || i >= db)
            throw"tulidnex";
        return Tarolo[i];
    }


    Filmtar(const Filmtar& rhs) {       //7. labor alapj�n
        //copy(rhs);
        //felszabadit();
        db = 0;
        Tarolo = NULL;
        *this = rhs;
    }

    void copy(Filmtar const& rhs);

    Film* get_last();
    int get_db();
    void set_db(int ujdb);
    int get_capacity();
    void set_capacity(int ertek);
    void ujfilm_felvetel();


    void hozzafuz(Film& ujfilm);
    void torles(string ezt);

    void szerkesztes(string ezt);

    void savetofile();

    void kereses();

    void listaz(); 

    void megnyit();

    void felszabadit();

    ~Filmtar() { 
       /*felszabadit();
       db = 0;*/


        delete[] Tarolo;              
        db = 0;
    }

    

    //void tesztek();
};